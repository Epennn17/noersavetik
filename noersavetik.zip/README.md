# TikTok Downloader

Website full-stack: paste link TikTok → dapat thumbnail, judul, tombol download video & audio.

## Struktur Folder

```
project/
├── server/
│   ├── routes/
│   │     └── download.js     # endpoint GET /api/tiktok
│   ├── app.js                 # entry point Express
│   ├── package.json
│   └── .env                   # PORT=3000
│
└── client/
    └── index.html        # HTML + CSS + JS digabung jadi satu file
```

## Cara Menjalankan

1. Masuk ke folder server:
   ```
   cd project/server
   ```

2. Install dependency:
   ```
   npm install
   ```

3. Jalankan server:
   ```
   npm start
   ```

4. Buka browser ke:
   ```
   http://localhost:3000
   ```

   Server ini juga otomatis menyajikan file frontend dari folder `client/`, jadi tidak perlu server terpisah untuk HTML/CSS/JS.

## Cara Kerja

- Frontend (di dalam `<script>` pada `client/index.html`) mengirim request ke `/api/tiktok?url=...` di server sendiri — **tidak pernah** langsung ke API pihak ketiga.
- Backend (`server/routes/download.js`) yang meneruskan request ke `https://api.saipulanuar.eu.org/api/download/ttdl`, lalu membersihkan hasilnya jadi format JSON yang rapi:
  ```json
  {
    "success": true,
    "title": "...",
    "thumbnail": "...",
    "video": "...",
    "audio": "..."
  }
  ```
- Kalau gagal:
  ```json
  {
    "success": false,
    "message": "Failed to fetch TikTok data."
  }
  ```

## Catatan Penting

- Karena API pihak ketiga bisa berubah sewaktu-waktu format responsnya, `download.js` sudah dibuat "defensif" — mencoba beberapa nama field yang umum (`video`/`play`/`no_watermark`, dll). Kalau ternyata API mengembalikan struktur berbeda, cek response mentahnya (misal dengan `console.log(data)` sementara di `download.js`) lalu sesuaikan field mapping-nya.
- Timeout request ke API pihak ketiga diset 15 detik.
- Tidak ada error internal (stack trace dsb) yang dikirim ke client — hanya pesan umum.

## Menjalankan dari HP (Spck Editor)

1. Upload/isi semua file sesuai struktur folder di atas.
2. Buka terminal Spck Editor, `cd` ke folder `server`.
3. Jalankan `npm install` lalu `npm start`.
4. Buka `http://localhost:3000` di browser HP kamu (atau gunakan fitur preview kalau Spck menyediakannya).
